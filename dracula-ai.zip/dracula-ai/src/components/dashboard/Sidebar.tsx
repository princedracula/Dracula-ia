import Link from "next/link";
import { sidebarNav, site } from "@/lib/config";
export function Sidebar() {
  return (
    <aside className="border-b border-steel/10 bg-crypt md:min-h-screen md:w-64 md:border-b-0 md:border-r">
      <p className="px-5 py-4 font-display tracking-[0.2em] text-steel">{site.name}</p>
      <nav className="flex gap-1 overflow-x-auto px-3 pb-3 md:flex-col md:overflow-visible">
        {sidebarNav.map((n, i) => (
          <Link key={n.label} href={n.href}
            className={`whitespace-nowrap rounded-sm px-3 py-2 text-sm ${i===0 ? "bg-blood/25 text-white" : "text-ash hover:bg-white/5 hover:text-white"}`}>{n.label}</Link>
        ))}
      </nav>
    </aside>
  );
}
