"use client";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
export function SignOutButton() {
  const router = useRouter();
  async function signOut() {
    await createClient().auth.signOut();
    router.push("/login"); router.refresh();
  }
  return <button onClick={signOut} className="rounded-sm border border-steel/30 px-4 py-2 text-sm text-steel hover:border-crimson hover:text-white">Se déconnecter</button>;
}
