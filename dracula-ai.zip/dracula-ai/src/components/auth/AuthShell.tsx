import type { ReactNode } from "react";
import { Logo } from "@/components/ui/Logo";
import { site } from "@/lib/config";
export function AuthShell({ title, children }: { title: string; children: ReactNode }) {
  return (
    <main className="relative grid min-h-screen place-items-center overflow-hidden px-5 py-12">
      <div aria-hidden className="absolute left-1/2 top-1/3 h-96 w-96 -translate-x-1/2 animate-pulseGlow rounded-full bg-[radial-gradient(circle,#7a0b1c_0%,transparent_70%)]" />
      <div className="relative w-full max-w-md rounded-md border border-steel/15 bg-crypt/90 p-8 shadow-glow">
        <Logo />
        <p className="mt-1 text-sm text-crimson">{site.slogan}</p>
        <h1 className="mt-8 font-display text-2xl text-steel">{title}</h1>
        {children}
      </div>
    </main>
  );
}
