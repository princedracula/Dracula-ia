"use client";
import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { validateRegister, authErrorMessage } from "@/lib/validation";
import { TextField } from "./TextField";

export function RegisterForm() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const name = String(f.get("name") ?? "").trim();
    const email = String(f.get("email") ?? "").trim();
    const password = String(f.get("password") ?? "");
    const invalid = validateRegister(name, email, password, String(f.get("confirm") ?? ""));
    if (invalid) return setError(invalid);
    setError(null); setLoading(true);
    const { data, error: err } = await createClient().auth.signUp({
      email, password,
      options: { data: { full_name: name }, emailRedirectTo: `${window.location.origin}/auth/callback` },
    });
    setLoading(false);
    if (err) return setError(authErrorMessage(err.message));
    if (data.user && data.user.identities?.length === 0) return setError("Cette adresse email est déjà utilisée.");
    if (data.session) { router.push("/dashboard"); router.refresh(); return; }
    setSuccess("Compte créé avec succès. Vérifie ta boîte mail pour confirmer ton adresse.");
  }
  if (success) return <p role="status" className="mt-6 text-steel">{success} <Link href="/login" className="underline">Se connecter</Link></p>;
  return (
    <form onSubmit={onSubmit} className="mt-6 space-y-4" noValidate>
      <TextField id="name" label="Nom" autoComplete="name" />
      <TextField id="email" label="Email" type="email" autoComplete="email" />
      <TextField id="password" label="Mot de passe" type="password" autoComplete="new-password" />
      <TextField id="confirm" label="Confirmer le mot de passe" type="password" autoComplete="new-password" />
      {error && <p role="alert" className="text-sm text-crimson">{error}</p>}
      <button disabled={loading} className="w-full rounded-sm bg-blood px-6 py-3 text-sm font-medium text-white shadow-glow hover:bg-crimson disabled:opacity-60">
        {loading ? "Création…" : "Créer mon compte"}
      </button>
      <p className="text-center text-sm text-ash">Déjà inscrit ? <Link href="/login" className="text-steel underline">Se connecter</Link></p>
    </form>
  );
}
