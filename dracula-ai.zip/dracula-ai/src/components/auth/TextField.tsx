import type { InputHTMLAttributes } from "react";
export function TextField({ label, id, ...props }: { label: string; id: string } & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-sm text-ash">{label}</label>
      <input id={id} name={id} required {...props}
        className="w-full rounded-sm border border-steel/20 bg-abyss px-4 py-3 text-steel placeholder:text-ash/50 focus:border-crimson" />
    </div>
  );
}
