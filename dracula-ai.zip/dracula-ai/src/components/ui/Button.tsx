import Link from "next/link";
import type { ReactNode } from "react";
export function Button({ href, children, variant="primary" }: { href: string; children: ReactNode; variant?: "primary"|"ghost" }) {
  const base = "inline-flex items-center justify-center rounded-sm px-6 py-3 text-sm font-medium transition-colors";
  const styles = variant==="primary"
    ? "bg-blood text-white hover:bg-crimson shadow-glow"
    : "border border-steel/30 text-steel hover:border-crimson hover:text-white";
  return <Link href={href} className={`${base} ${styles}`}>{children}</Link>;
}
