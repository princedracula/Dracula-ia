import type { DraculaModule } from "@/types";
export function ModuleCard({ m }: { m: DraculaModule }) {
  return (
    <article className="rounded-md border border-steel/15 bg-crypt p-6 transition-colors hover:border-crimson/60">
      <div className="text-3xl" aria-hidden>{m.icon}</div>
      <h3 className="mt-4 font-display text-xl text-steel">{m.name}</h3>
      <p className="mt-2 text-sm leading-relaxed text-ash">{m.description}</p>
      {m.status==="soon" && <p className="mt-4 text-xs text-crimson">Disponible prochainement</p>}
    </article>
  );
}
