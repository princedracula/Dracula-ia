import Link from "next/link";
import { site } from "@/lib/config";
// Emplacement logo : remplacer le <span> par <Image src="/brand/logo.svg" .../> quand l'asset sera prêt.
export function Logo() {
  return (
    <Link href="/" className="flex items-center gap-3" aria-label={site.name}>
      <span className="grid h-9 w-9 place-items-center rounded-sm border border-dashed border-steel/40 text-[10px] text-ash">LOGO</span>
      <span className="font-display text-lg tracking-[0.2em] text-steel">{site.name}</span>
    </Link>
  );
}
