import { modules } from "@/modules/registry";
import { ModuleCard } from "@/components/ui/ModuleCard";
export function Modules() {
  return (
    <section id="fonctionnalites" className="mx-auto max-w-6xl px-5 py-20">
      <h2 className="font-display text-3xl text-steel">Les modules Dracula</h2>
      <p className="mt-2 text-ash">Quatre outils, un seul espace. D'autres arriveront.</p>
      <div id="agents" className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {modules.map(m => <ModuleCard key={m.id} m={m} />)}
      </div>
    </section>
  );
}
