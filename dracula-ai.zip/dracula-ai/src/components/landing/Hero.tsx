import { Button } from "@/components/ui/Button";
import { site } from "@/lib/config";
export function Hero() {
  return (
    <section id="accueil" className="relative overflow-hidden">
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-20 md:grid-cols-2 md:py-32">
        <div>
          <h1 className="font-display text-5xl tracking-[0.12em] text-steel sm:text-6xl">{site.name}</h1>
          <p className="mt-3 font-display text-2xl text-crimson">{site.slogan}</p>
          <p className="mt-6 max-w-md text-lg leading-relaxed text-ash">Une plateforme intelligente qui réunit plusieurs outils et agents IA dans un seul espace.</p>
          <div className="mt-9 flex flex-wrap gap-4">
            <Button href="/register">Commencer gratuitement</Button>
            <Button href="#fonctionnalites" variant="ghost">Découvrir Dracula</Button>
          </div>
        </div>
        {/* Visuel : orbe rouge sous anneaux argentés. Remplaçable par une image/3D plus tard. */}
        <div className="relative mx-auto aspect-square w-full max-w-md" aria-hidden>
          <div className="absolute inset-[15%] animate-pulseGlow rounded-full bg-[radial-gradient(circle,#e11d48_0%,#7a0b1c_45%,transparent_70%)] blur-sm" />
          <div className="absolute inset-0 rounded-full border border-steel/25" />
          <div className="absolute inset-[10%] rounded-full border border-steel/15" />
          <div className="absolute inset-[30%] rounded-full border border-crimson/40" />
          <div className="absolute inset-[44%] rounded-full bg-abyss shadow-glow" />
        </div>
      </div>
    </section>
  );
}
