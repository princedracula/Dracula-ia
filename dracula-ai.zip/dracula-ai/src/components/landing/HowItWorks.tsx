const steps = ["Choisis ton outil","Décris ce que tu veux créer","Laisse Dracula AI travailler"];
export function HowItWorks() {
  return (
    <section id="tarifs" className="mx-auto max-w-6xl px-5 py-20">
      <h2 className="font-display text-3xl text-steel">Comment ça marche</h2>
      <ol className="mt-10 grid gap-5 md:grid-cols-3">
        {steps.map((s, i) => (
          <li key={s} className="rounded-md border border-steel/15 bg-crypt p-6">
            <span className="font-display text-3xl text-crimson">{i + 1}</span>
            <p className="mt-3 text-steel">{s}</p>
          </li>
        ))}
      </ol>
    </section>
  );
}
