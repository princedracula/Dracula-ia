import { NextResponse, type NextRequest } from "next/server";
import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { getSupabaseEnv } from "@/lib/supabase/env";

export async function middleware(request: NextRequest) {
  const { url, publishableKey } = getSupabaseEnv();
  let response = NextResponse.next({ request });
  const supabase = createServerClient(url, publishableKey, {
    cookies: {
      getAll: () => request.cookies.getAll(),
      setAll(list: { name: string; value: string; options: CookieOptions }[]) {
        list.forEach(({ name, value }) => request.cookies.set(name, value));
        response = NextResponse.next({ request });
        list.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
      },
    },
  });
  const { data: { user } } = await supabase.auth.getUser(); // validé côté serveur Supabase
  const path = request.nextUrl.pathname;

  // Redirection en conservant les cookies de session éventuellement rafraîchis.
  const redirectTo = (target: string) => {
    const r = NextResponse.redirect(new URL(target, request.url));
    response.cookies.getAll().forEach(c => r.cookies.set(c));
    return r;
  };
  if (!user && path.startsWith("/dashboard")) return redirectTo("/login");
  if (user && (path === "/login" || path === "/register")) return redirectTo("/dashboard");
  return response;
}
// La landing page n'est pas concernée par le middleware.
export const config = { matcher: ["/dashboard/:path*", "/login", "/register"] };
