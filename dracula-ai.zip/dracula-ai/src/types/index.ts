export type ModuleId = "code" | "asmr" | "video" | "agents";
export interface DraculaModule { id: ModuleId; name: string; icon: string; description: string; href: string; status: "soon" | "live"; }
export interface NavItem { label: string; href: string; }
