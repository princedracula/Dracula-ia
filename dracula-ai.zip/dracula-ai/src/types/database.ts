import type { ModuleId } from "./index";
export type Role = "user" | "admin";
export type Plan = "free" | "daily" | "weekly" | "monthly" | "annual";
export type SubscriptionStatus = "active" | "expired" | "cancelled" | "pending";
export type GenerationStatus = "pending" | "processing" | "completed" | "failed";
export interface Profile { id: string; user_id: string; full_name: string | null; email: string | null; avatar_url: string | null; role: Role; credits: number; created_at: string; updated_at: string; }
export interface Subscription { id: string; user_id: string; plan: Plan; status: SubscriptionStatus; starts_at: string | null; expires_at: string | null; credits_total: number; credits_remaining: number; created_at: string; updated_at: string; }
export interface Generation { id: string; user_id: string; module: ModuleId; prompt: string | null; status: GenerationStatus; credits_used: number; result_url: string | null; created_at: string; }
