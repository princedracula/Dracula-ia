import type { NavItem } from "@/types";
export const site = { name:"DRACULA AI", slogan:"IA DARCK" };
export const mainNav: NavItem[] = [
  { label:"Accueil", href:"/#accueil" }, { label:"Fonctionnalités", href:"/#fonctionnalites" },
  { label:"Agents", href:"/#agents" }, { label:"Tarifs", href:"/#tarifs" }, { label:"Connexion", href:"/login" },
];
export const footerLinks: NavItem[] = [
  ...mainNav.slice(0,4), { label:"Conditions", href:"#" }, { label:"Confidentialité", href:"#" }, { label:"Contact", href:"#" },
];
export const sidebarNav: NavItem[] = [
  { label:"🏠 Accueil", href:"/dashboard" }, { label:"💻 Dracula Code", href:"/dashboard" },
  { label:"🎧 Dracula ASMR", href:"/dashboard" }, { label:"🎬 Dracula Video", href:"/dashboard" },
  { label:"🤖 Dracula Agents", href:"/dashboard" }, { label:"📁 Mes créations", href:"/dashboard" },
  { label:"💳 Abonnement", href:"/dashboard" }, { label:"⚙️ Paramètres", href:"/dashboard" },
];
