import type { DraculaModule } from "@/types";
// Ajouter un module = ajouter une entrée ici.
export const modules: DraculaModule[] = [
  { id:"code", name:"Dracula Code", icon:"💻", description:"Développement Full-Stack assisté par IA.", href:"/dashboard", status:"soon" },
  { id:"asmr", name:"Dracula ASMR", icon:"🎧", description:"Création de concepts, prompts et contenus ASMR.", href:"/dashboard", status:"soon" },
  { id:"video", name:"Dracula Video", icon:"🎬", description:"Création et transformation de contenus vidéo.", href:"/dashboard", status:"soon" },
  { id:"agents", name:"Dracula Agents", icon:"🤖", description:"Agents IA spécialisés et marketplace de Skills.", href:"/dashboard", status:"soon" },
];
