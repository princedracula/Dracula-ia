import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { modules } from "@/modules/registry";
import { ModuleCard } from "@/components/ui/ModuleCard";
import { SignOutButton } from "@/components/dashboard/SignOutButton";
import type { Profile, Subscription } from "@/types/database";

export default async function DashboardHome() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const [{ data: profile, error: profileError }, { data: sub }] = await Promise.all([
    supabase.from("profiles").select("*").eq("user_id", user.id).maybeSingle<Profile>(),
    supabase.from("subscriptions").select("*").eq("user_id", user.id).eq("status", "active")
      .order("created_at", { ascending: false }).limit(1).maybeSingle<Subscription>(),
  ]);

  const name = profile?.full_name || (user.user_metadata?.full_name as string | undefined) || user.email || "";
  const plan = (sub?.plan ?? "free").toUpperCase();
  const credits = profile?.credits ?? 0;
  const expires = sub?.expires_at ? new Date(sub.expires_at).toLocaleDateString("fr-FR") : "—";

  return (
    <main className="p-5 md:p-10">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl text-steel">Bonjour, {name}</h1>
          <p className="mt-2 text-ash">Que veux-tu créer aujourd'hui ?</p>
        </div>
        <SignOutButton />
      </div>
      {(profileError || !profile) && (
        <p role="alert" className="mt-6 rounded-sm border border-crimson/40 p-4 text-sm text-crimson">
          Impossible de charger ton profil. Vérifie que le SQL Supabase a bien été exécuté.
        </p>
      )}
      <dl className="mt-8 grid gap-4 sm:grid-cols-3">
        {[["Plan actuel", plan], ["Crédits disponibles", String(credits)], ["Date d'expiration", expires]].map(([k, v]) => (
          <div key={k} className="rounded-md border border-steel/15 bg-crypt p-5">
            <dt className="text-sm text-ash">{k}</dt>
            <dd className="mt-1 font-display text-2xl text-steel">{v}</dd>
          </div>
        ))}
      </dl>
      <div className="mt-10 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        {modules.map(m => <ModuleCard key={m.id} m={m} />)}
      </div>
    </main>
  );
}
