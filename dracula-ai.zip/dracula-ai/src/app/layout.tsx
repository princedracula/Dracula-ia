import type { Metadata } from "next";
import "@/styles/globals.css";
export const metadata: Metadata = { title: "DRACULA AI — IA DARCK", description: "Une plateforme intelligente qui réunit plusieurs outils et agents IA dans un seul espace." };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="fr"><body>{children}</body></html>;
}
