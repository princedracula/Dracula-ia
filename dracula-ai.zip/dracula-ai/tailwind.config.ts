import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: { extend: {
    colors: { abyss:"#07060a", crypt:"#110a0e", blood:"#b0102a", crimson:"#e11d48", steel:"#c4c9d2", ash:"#8a8f99" },
    fontFamily: { display:["Georgia","Times New Roman","serif"], sans:["system-ui","Segoe UI","sans-serif"] },
    boxShadow: { glow:"0 0 40px -8px rgba(225,29,72,.45)" },
    keyframes: { pulseGlow:{ "0%,100%":{opacity:".55"}, "50%":{opacity:"1"} } },
    animation: { pulseGlow:"pulseGlow 5s ease-in-out infinite" },
  } },
  plugins: [],
};
export default config;
