Placez ici le logo : public/brand/logo.svg (ou .png), puis modifiez src/components/ui/Logo.tsx.
